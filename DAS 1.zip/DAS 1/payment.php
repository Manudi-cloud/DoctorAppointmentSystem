<?php
session_start();
include("DBConnection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['appointment_id'], $_POST['payment_method'])) {
        die("Invalid request.");
    }

    $appointment_id = intval($_POST['appointment_id']);
    $method = $_POST['payment_method'];

    // Insert payment record
    $stmt = $con->prepare("INSERT INTO payment (appointment_Id, method, status, created_at) VALUES (?, ?, 'Pending', NOW())");
    if (!$stmt) {
        die("SQL Error: " . $con->error);
    }
    $stmt->bind_param("is", $appointment_id, $method);

    if ($stmt->execute()) {
        // Redirect to payment success page
        header("Location: payment_confirm.php?appointment_Id=" . $appointment_id);
        exit;
    } else {
        die("Error saving payment: " . $stmt->error);
    }
}
?>
