<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
</head>
<body>
  <h2>Reset Your Password</h2>
  <form method="POST" action="reset_password.php">
    <label>Email:</label>
    <input type="email" name="email" required>
    <br><br>
    <label>New Password:</label>
    <input type="password" name="new_password" required>
    <br><br>
    <button type="submit">Reset</button>
  </form>
</body>
</html>
