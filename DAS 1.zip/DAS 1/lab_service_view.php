<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Laboratory Services</title>
  <link rel="icon" type="image/x-icon" href="../images/icon2.ico">
  <link rel="stylesheet" href="lab.css">
</head>
<body>

  <!-- Include header -->
  <?php include('header.php'); ?>

  <!-- Title Section -->
  <div class="lab-title">
    <h1>Laboratory Services</h1>
    <p>Accurate, reliable, and fast diagnostic testing for better healthcare decisions.</p>
  </div>

  <!-- Services Section -->
  <div class="lab-container">
    <div class="lab-card">
      <img src="images/lab1.jpg" alt="Blood Test">
      <h2>Blood Tests</h2>
      <p>Comprehensive blood analysis including CBC, sugar levels, cholesterol, and more for accurate diagnosis.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab2.jpg" alt="X-Ray">
      <h2>X-Ray Imaging</h2>
      <p>High-quality digital X-rays for quick and precise detection of bone and chest conditions.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab3.jpg" alt="Scan">
      <h2>Scans & Ultrasound</h2>
      <p>Modern ultrasound and scanning facilities to ensure effective and safe medical imaging.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab4.jpg" alt="Urine Test">
      <h2>Urine Tests</h2>
      <p>Routine and advanced urine analysis to assist in the diagnosis of infections and other conditions.</p>
     
    </div>

    <div class="lab-card">
      <img src="images/lab5.jpg" alt="ECG">
      <h2>ECG (Electrocardiogram)</h2>
      <p>Non-invasive test to measure heart rhythms and detect cardiac conditions.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab6.jpg" alt="MRI">
      <h2>MRI Scans</h2>
      <p>Advanced magnetic imaging for detailed internal organ, brain, and spine analysis.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab7.jpg" alt="Allergy Testing">
      <h2>Allergy Testing</h2>
      <p>Identify common food, pollen, dust, and skin allergies through modern lab testing.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab8.jpg" alt="Liver Function">
      <h2>Liver & Kidney Function Tests</h2>
      <p>Comprehensive panels to monitor liver enzymes and kidney health indicators.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab9.jpg" alt="Hormone Test">
      <h2>Hormone & Thyroid Tests</h2>
      <p>Accurate analysis of hormone levels to diagnose thyroid and endocrine disorders.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab10.jpg" alt="COVID-19 Test">
      <h2>COVID-19 / PCR Tests</h2>
      <p>Reliable PCR and rapid antigen testing for COVID-19 detection and travel requirements.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab11.jpg" alt="Vitamin Test">
      <h2>Vitamin & Mineral Tests</h2>
      <p>Check essential vitamins like Vitamin D, B12, iron, and minerals to maintain good health.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab12.jpg" alt="DNA Test">
      <h2>DNA & Genetic Testing</h2>
      <p>Advanced genetic screening for inherited disorders, ancestry, and personalized medicine.</p>
      
    </div>

    </div>

  </div>

  <!-- Include footer -->
  <?php include('footer.php'); ?>

</body>
</html>
