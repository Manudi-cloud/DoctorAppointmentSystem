<?php
include("DBConnection.php");

if (isset($_POST['update'])) {
    $patientId   = $_POST["patient_Id"];
    $name        = $_POST["name"];
    $gender      = $_POST["gender"];
    $address     = $_POST["address"];
    $contactno   = $_POST["contactnumber"];
    $dob         = $_POST["dob"];
    $pemail      = $_POST["email_address"];

    // Prepare SQL update query
    $sql = "UPDATE patient_details SET name=?, gender=?, address=?, contactnumber=?, dob=?, email_address=? WHERE patient_Id=?";

    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssssssi", $name, $gender, $address, $contactno, $dob, $pemail, $patientId);

    if ($stmt->execute()) {
        echo "<script>alert('Patient details updated successfully'); window.location='view_Patients.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); history.back();</script>";
    }

    $stmt->close();
}
$con->close();
?>

