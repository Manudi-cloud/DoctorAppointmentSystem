<?php
session_start();
include('DBConnection.php');

// Fetch all users from the database
$sql = "SELECT * FROM tblreview";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<style>
    /* styles.css */

/* General Page Styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: 50px auto;
    padding: 20px;
    background: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

h1 {
    text-align: center;
    color: #333;
}

/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

thead tr {
    background-color: #f8f8f8;
}

th, td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #007bff;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #f1f1f1;
}

td {
    color: #333;
}

/* Button Styling */
.btn-primary {
    display: inline-block;
    padding: 10px 20px;
    color: #fff;
    background-color: #007bff;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 20px;
    transition: background-color 0.3s ease;
}

.btn-primary:hover {
    background-color: #0056b3;
}

.row {
    text-align: center;
}

@media (max-width: 768px) {
    .container {
        width: 90%;
    }

    th, td {
        padding: 10px;
    }

    .btn-primary {
        padding: 8px 15px;
    }
}

    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reviews</title>
    <link rel="icon" type="image/x-icon" href="../Pages/images/logo new.ico">

    
</head>
<body>

<div class="container">
    <h1>Patient Reviews</h1>
    
    <table id="userTable">
        <thead>
            <tr>
                <th>Name</th>
                <th>Short description</th>
                <th>Review</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['patient_Name']); ?></td>
                        <td><?php echo htmlspecialchars($row['review_brief']); ?></td>
                        <td><?php echo htmlspecialchars($row['review_detail']); ?></td>
                        
                        
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No reviews found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
            <div class="row">
                            <div class="col-sm-8 col-sm-offset-2">
                                <a href="admin_dashboard.html" class="btn btn-primary">Back to Dashboard</a>
                            </div>
            </div>
</body>
</html>

<?php
// Close the database connection
mysqli_close($con);
?>

