<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hospital Official Website</title>
  <link rel="icon" type="image/x-icon" href="./images/icon2.ico">
  <link rel="stylesheet" href="header.css">
</head>
<body>
  <header>
    <div class="header-container">
      <!-- Logo -->
      <a href="index.php" class="logo-link">
        <img class="logo" src="images/logoN.jpg" alt="Logo">
      </a>
      
      <!-- Navigation -->
      <nav class="navbar">
        <ul class="nav-links">
          <li><a href="index.php" class="active">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="gallery.php">Gallery</a></li>
          <li><a href="guest_view_doctor.php">Specialists</a></li>
          <li><a href="lab_service_view.php">Laboratory Service</a></li>
          <li class="login-btn"><a href="login.php">Login</a></li>
        </ul>
      </nav>
    </div>
  </header>
</body>
</html>
