<?php
$page_title = "Doctor Registration Form";
include("DBConnection.php");

$msg ='';
$error ='';

if(isset($_POST['submit'])) {

    $courtesy_title   = $_POST["txtdoc_title"];
    $doc_name         = $_POST["txtdoc_name"];
    $doc_email        = $_POST["txtdoc_email"];
    $doc_contactno    = $_POST["txtdoc_contact"];
    $doc_DOB          = $_POST["txtdoc_dob"];
    $doc_gender       = $_POST["txtdoc_gender"];
    $specialization   = $_POST["txtspecialization"];
    $qualifications   = $_POST["txtqualifications"];
    $years_experienced= $_POST["txtex_years"];
    $registration_no  = $_POST["txtreg_no"];
    $dpassword = $_POST["txtpassword"];

    // Handle image upload 
    if(isset($_FILES['doctorimage']) && $_FILES['doctorimage']['error'] == 0) {
        $doctor_pic = file_get_contents($_FILES['doctorimage']['tmp_name']);
    } else {
        $doctor_pic = null;
    }

    // Check duplicate email
    $stmt = $con->prepare("SELECT COUNT(*) FROM doctor_details WHERE doc_email = ?");
    $stmt->bind_param("s", $doc_email);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $error = "Email already exists.";
    } else {
        $stmt = $con->prepare("INSERT INTO doctor_details (courtesy_title, doc_name, doc_email, doc_contactno, doc_DOB, doc_gender, specialization, qualifications, years_experienced, registration_no, dpassword, doc_pic) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if($stmt) {
            $stmt->bind_param("ssssssssssss", $courtesy_title, $doc_name, $doc_email, $doc_contactno, $doc_DOB, $doc_gender, $specialization, $qualifications, $years_experienced, $registration_no, $dpassword, $doctor_pic);

            if($stmt->execute()) {
                $msg = "Successfully added doctor details!";
            } else {
                $error = "Something went wrong: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Failed to prepare statement: " . $con->error;
        }
    }
}
$con->close();
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Doctor Registration</title>
    <link rel="stylesheet" href="doctor_reg.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
</head>
<body>
<div class="form-container">
    <h3>Doctor Registration</h3>
    <form method="post" enctype="multipart/form-data">
        <label>Courtesy Title</label>
        <select name="txtdoc_title" required>
            <option value="">Select</option>
            <option value="Mr">Mr</option>
            <option value="Mrs">Mrs</option>
            <option value="Ms">Ms</option>
            <option value="Prof">Prof</option>
        </select><br>

        <label>Name:</label>
        <input type="text" name="txtdoc_name" required><br>

        <label>Email:</label>
        <input type="email" name="txtdoc_email" required><br>

        <label>Contact Number:</label>
        <input type="text" name="txtdoc_contact" required><br>

        <label>Date of Birth:</label>
        <input type="date" name="txtdoc_dob" required><br>

        <label>Gender:</label>
        <select name="txtdoc_gender" required>
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select><br>

        <label>Specialization:</label>
        <input type="text" name="txtspecialization" required><br>

        <label>Qualifications:</label>
        <input type="text" name="txtqualifications" required><br>

        <label>Experience (years):</label>
        <input type="number" name="txtex_years" required><br>

        <label>Registration Number:</label>
        <input type="text" name="txtreg_no" required><br>

        <label>Password:</label>
        <input type="password" name="txtpassword" required><br>

        <label>Doctor’s Photograph:</label>
        <input type="file" name="doctorimage" accept="image/*" required><br><br>

        <button type="submit" name="submit">Register</button>
        <a href="admin_dashboard.html">Back</a>
    </form>
</div>

<?php if ($msg): ?>
<script>
    swal("Success!", "<?php echo addslashes($msg); ?>", "success");
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
    swal("Error!", "<?php echo addslashes($error); ?>", "error");
</script>
<?php endif; ?>

</body>
</html>
