<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Facilities</title>
  <link rel="stylesheet" href="facilities.css">
</head>
<body>

  <!-- Include header -->
  <?php include('header.php'); ?>

  <div class="facilities-section">
    <h1 class="title">Our Facilities</h1>
    <p class="subtitle">We provide a wide range of healthcare services to support your wellness journey.</p>

    <div class="facility">
      <img src="images/facility1.jpg" alt="Doctor Appointments">
      <div class="info">
        <h2>Doctor Appointments</h2>
        <p>Book appointments with experienced doctors easily through our system.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility2.jpg" alt="Lab Tests">
      <div class="info">
        <h2>Laboratory Tests</h2>
        <p>Get accurate and fast lab tests including blood, urine, scans, and more.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility3.jpg" alt="Pharmacy">
      <div class="info">
        <h2>Pharmacy</h2>
        <p>Order prescribed medicines online and collect them at your convenience.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility4.jpg" alt="Emergency">
      <div class="info">
        <h2>Emergency Care</h2>
        <p>24/7 emergency services with quick access to doctors and specialists.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility5.jpg" alt="Health Records">
      <div class="info">
        <h2>Health Records</h2>
        <p>Securely store and manage your health reports and prescriptions online.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility6.jpg" alt="Support">
      <div class="info">
        <h2>Customer Support</h2>
        <p>Our team is here to help with any queries about your healthcare needs.</p>
      </div>
    </div>
  </div>

  <!-- Include footer -->
  <?php include('footer.php'); ?>

</body>
</html>
