<?php
session_start();
include("DBConnection.php");

// ✅ Directly use session variable
$patient_id = $_SESSION['patient_id'];

$sql = "SELECT a.appointment_Id, a.status, a.created_at,
               d.doc_name, av.available_date, av.start_time, av.end_time,
               p.method AS payment_method, p.status AS payment_status
        FROM appointment a
        JOIN doctor_details d ON a.doctor_id = d.doctor_Id
        JOIN doctor_availabiility av ON a.availability_id = av.id
        LEFT JOIN payment p ON a.appointment_Id = p.appointment_Id
        WHERE a.patient_id = ?
        ORDER BY av.available_date, av.start_time";

$stmt = $con->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Appointments</title>
    <link rel="stylesheet" href="style.css">
    <style>
    
    /* General Page Styling */
    
    body {
      font-family: "Segoe UI", Arial, sans-serif;
    background: #f4f8fb;
    margin: 0;
    padding: 0;
    color: #1d1d18ff;
    }

/* Container */
.container {
    width: 90%;
    max-width: 1000px;
    margin: 40px auto;
    background: #fff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(46, 197, 235, 0.1);
}

/* Title */
.container h2 {
    text-align: center;
    color: #3106afff;
    margin-bottom: 25px;
    font-size: 26px;
    font-weight: 600;
}

/* Table Styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    padding: 12px 15px;
    text-align: center;
    border: 1px solid #ddd;
}

table th {
    background: #2083e6ff;
    color: #fff;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-size: 14px;
}

table tr:nth-child(even) {
    background: #f9f9f9;
}

table tr:hover {
    background: #f1f7ff;
}

/* Status Styling */
td:nth-child(5) {
    font-weight: bold;
    color: #007bff;
}

/* Payment Status */
td:nth-child(6) {
    font-size: 14px;
    font-weight: 500;
}

/* Back Button */
.back-button {
    text-align: center;
    margin-bottom: 30px;
}

.back-button a {
    display: inline-block;
    text-decoration: none;
    background: #002244;
    color: #fff;
    padding: 10px 20px;
    border-radius: 8px;
    transition: 0.3s;
    font-weight: 500;
}

.back-button a:hover {
    background: #0056b3;
}
</style>


</head>
<body>
<div class="container">
    <h2>My Appointments</h2>

    <?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>#</th>
            <th>Doctor</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Payment</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['appointment_Id']; ?></td>
            <td><?php echo htmlspecialchars($row['doc_name']); ?></td>
            <td><?php echo $row['available_date']; ?></td>
            <td><?php echo $row['start_time'] . " - " . $row['end_time']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
                <?php 
                    if ($row['payment_status']) {
                        echo $row['payment_method'] . " (" . $row['payment_status'] . ")";
                    } else {
                        echo "Not Paid";
                    }
                ?>
            </td>

            
        </tr>
        <?php endwhile; ?>
    </table>
    <?php else: ?>
        <p>No appointments booked yet.</p>
    <?php endif; ?>
</div>
<div class="back-button">
    <a href="patient_dashboard.html">Back</a>
</div>
</body>
</html>
