<?php
include("DBConnection.php");

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$test_id = intval($_GET['id']);


// ✅ Correct table name: labtest_details
$stmt = $con->prepare("SELECT test_id, test_name, description, sample_required, report_time, preparation, price, test_image 
                       FROM labtest_details 
                       WHERE test_id = ?");
if (!$stmt) {
    die("SQL Error: " . $con->error);
}

$stmt->bind_param("i", $test_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Lab test not found.");
}

$test = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($test['test_name']); ?> - Details</title>
  <link rel="stylesheet" href="lab.css">
  
</head>
<body>

  <?php include('header.php'); ?>

  <div class="lab-details">
    <h2><?php echo htmlspecialchars($test['test_name']); ?></h2>

    <!-- Show image if available -->
    <?php if (!empty($test['test_image'])): ?>
      <img src="data:image/jpeg;base64,<?php echo base64_encode($test['test_image']); ?>" 
           alt="<?php echo htmlspecialchars($test['test_name']); ?>" 
           class="lab-img">
    <?php endif; ?>

    <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($test['description'])); ?></p>
    <p><strong>Sample Required:</strong> <?php echo htmlspecialchars($test['sample_required']); ?></p>
    <p><strong>Report Time:</strong> <?php echo htmlspecialchars($test['report_time']); ?></p>
    <p><strong>Preparation:</strong> <?php echo nl2br(htmlspecialchars($test['preparation'])); ?></p>
    <p><strong>Price:</strong> Rs. <?php echo number_format($test['price'], 2); ?></p>

    <a href="my_lab_bookings.php?id=<?php echo $test['test_id']; ?>" class="lab-btn">Confirm Booking</a>
  </div>

  <?php include('footer.php'); ?>
</body>
</html>
