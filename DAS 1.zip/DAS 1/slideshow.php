<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slide Show</title>
    <link rel="icon" type="image/x-icon" href="../Pages/images/logo new.ico">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="slideshow">
    <div class="slide" id="slide1">
        <img src="images/bg3.jpg" alt="Slide 1">
        <div class="description">
        <h2></h2>
        <p></p>      
        </div>
    </div>

    <div class="slide" id="slide2">
        <img src="images/bg2.jpg" alt="Slide 2">
        <div class="description">
        <h2></h2>
        <p></p>      
        </div>
    </div>

    <div class="slide" id="slide3">
        <img src="images/bg4.jpg" alt="Slide 3">
        <div class="description">
        <h2></h2>
        <p></p>     
        </div>
    </div>

        <div class="slide" id="slide4">
        <img src="images/bg5.jpg" alt="Slide 4">
        <div class="description">
        <h2></h2>
        <p></p>    
        </div>
    </div>

        <div class="slide" id="slide5">
        <img src="images/bg6.jpg" alt="Slide 5">
        <div class="description">
        <h2></h2>
        <p></p>     
        </div>
    </div>
</div>

</body>
</html>
