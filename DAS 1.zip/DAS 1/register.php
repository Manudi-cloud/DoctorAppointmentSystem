<?php
 $page_title = "Registration Form";
 include("DBConnection.php");


$msg ='';
$error ='';

if(isset($_POST['submit'])) {

    $name = $_POST["txtname"];
    $gender =$_POST["txtgender"];
    $address = $_POST["txtaddress"];
    $contactno = $_POST["txtcontact"];
    $dob = $_POST["txtDOB"];
    $pemail = $_POST["txtemail"];
    $username = $_POST["txtusername"];
    $pswd = $_POST["txtpswd"];


// Check for duplicate username or email
    $stmt = $con->prepare("SELECT COUNT(*) FROM patient_details WHERE username = ? OR email_address = ?");
    $stmt->bind_param("ss", $username, $pemail);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $error = "Username or Email already exists.";
    } else {
        // Prepare and bind
        $stmt = $con->prepare("INSERT INTO patient_details (name, gender, address, contactnumber, dob, email_address, username, password ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt) {
            // Bind parameters 
            $stmt->bind_param("ssssssss", $name, $gender, $address, $contactno, $dob, $pemail, $username, $pswd );

            // Execute the statement
            if ($stmt->execute()) {
                $msg = "Patient Registration Successfull ! Welcome to Co-operative Hospital !";
            } else {
                $error = "Something went wrong. Please try again.";
            }
            
            // Close the statement
            $stmt->close();
        } else {
            $error = "Failed to prepare statement.";
        }
    }
}

// Close the database connection
$con->close();
?>


<!DOCTYPE HTML>
<html>
<head>
    <title>Patient Registration</title>
    <link rel="stylesheet" href="register.css">
    <link rel="icon" type="image/x-icon" href="./images/icon2.ico">
</head>
<body>


    <div class="form-container">
                    <div class="form-horizontal">
                        <h3> Patient Registration</h3>
                        <form class="form-horizontal" name="package" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="txtname" class="col-sm-2 control-label">Name</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtname" id="txtname" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtgender" class="col-sm-2 control-label">Gender</label>
                                <div class="col-sm-8">
                                    <input type="enum" class="form-control1" name="txtgender" id="txtgender" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtaddress" class="col-sm-2 control-label">Address</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtaddress" id="txtaddress" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtcontact" class="col-sm-2 control-label">Contact Number</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtcontact" id="txtcontact" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtDOB" class="col-sm-2 control-label">Date of Birth </label>
                                <div class="col-sm-8">
                                    <input type="date" class="form-control1" name="txtDOB" id="txtDOB" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtemail" class="col-sm-2 control-label">Email Address </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtemail" id="txtemail">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtusername" class="col-sm-2 control-label">Username</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtusername" id="txtusername" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtpswd" class="col-sm-2 control-label">Password</label>
                                <div class="col-sm-8">
                                    <input type="password" class="form-control" name="txtpswd" id="txtpswd" required>
                                </div>
                            </div>
                        
                            
                            <div class="btn-container">
                                    <button type="submit" name="submit" class="btn-primary btn">Create</button>
                            </div>

                            <a href="admin_dashboard.html">Back to dashboard</a>

                        </form>
                        <?php if ($msg): ?>
                            <script>
                                swal("Success!", "<?php echo $msg; ?>", "success");
                            </script>
                        <?php endif; ?>
                        <?php if ($error): ?>
                            <script>
                                swal("Error!", "<?php echo $error; ?>", "error");
                            </script>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="inner-block"></div>
            </div>
</body>
</html>