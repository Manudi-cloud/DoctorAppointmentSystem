<?php
include("DBConnection.php");

// Fetch active lab tests
$sql = "SELECT test_id, test_name, description, price, test_image FROM labtest_details";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Laboratory Services</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('header.php'); ?>

<div class="container my-4">
  <h1 class="mb-3">Laboratory Services</h1>
  <p>Accurate, reliable, and fast diagnostic testing for better healthcare decisions.</p>

  <div class="d-flex flex-wrap gap-3">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="card p-3" style="width:18rem;">
          <div class="text-center mb-2">
            <?php if (!empty($row['test_image'])): ?>
              <img src="data:image/jpeg;base64,<?= base64_encode($row['test_image']) ?>" 
                   alt="<?= htmlspecialchars($row['test_name']) ?>" 
                   class="rounded" style="width:100%;height:150px;object-fit:cover;">
            <?php else: ?>
              <img src="images/default.png" 
                   alt="Default Image" 
                   class="rounded" style="width:100%;height:150px;object-fit:cover;">
            <?php endif; ?>
          </div>
          <h5><?= htmlspecialchars($row['test_name']) ?></h5>
          <p class="mb-1"><?= htmlspecialchars($row['description']) ?></p>
          <p class="mb-1"><strong>Price:</strong> Rs. <?= number_format($row['price'], 2) ?></p>
          <div class="mt-3">
            <a href="lab_details.php?id=<?= urlencode($row['test_id']) ?>" class="btn btn-success">Book Now</a>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No lab tests available right now.</p>
    <?php endif; ?>
  </div>
</div>

<?php include('footer.php'); ?>

</body>
</html>
<?php $con->close(); ?>
