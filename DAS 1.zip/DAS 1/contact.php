<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="icon" type="image/x-icon" href="">
    <link rel="stylesheet" href="">
</head>
<body>

    <!--include header -->
    <?php include('header.php');?> 


 <!-- Header Start -->
 <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
            </div>
        </div>
    </div>
    <!-- Header End -->



 <div><?php include('enquiry.php');?> 

 
     
       
</div>
 
