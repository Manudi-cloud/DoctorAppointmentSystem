<?php
session_start();
include('DBConnection.php');

// Fetch all doctor details
$sql = "SELECT courtesy_title, doc_name, doc_email, doc_contactno, doc_DOB, doc_gender, specialization, qualifications, years_experienced, registration_no, doc_pic, doctor_Id 
        FROM doctor_details";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Doctors</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #0077b6;
        }
        .search-box {
            margin: 20px 0;
            text-align: center;
        }
        .search-box input {
            padding: 10px;
            width: 300px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background: #0077b6;
            color: white;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
        img {
            border-radius: 50%;
        }
        .back-button {
            margin-top: 20px;
            text-align: center;
        }
        .back-button a {
            padding: 10px 20px;
            background: #0077b6;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
        .compare-box {
            display: flex;
            justify-content: space-around;
            margin-top: 30px;
            padding: 20px;
            border: 2px dashed #0077b6;
            border-radius: 10px;
        }
        .compare-card {
            background: #f9f9f9;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 10px;
            width: 45%;
            text-align: left;
        }
        .compare-card img {
            display: block;
            margin: 0 auto 10px;
            border-radius: 50%;
            width: 80px;
            height: 80px;
        }
        .compare-btn {
            margin-top: 15px;
            display: block;
            text-align: center;
        }
        .compare-btn button {
            background: #00b4d8;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            font-size: 16px;
            cursor: pointer;
        }
        .compare-btn button:hover {
            background: #0077b6;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Doctor Management</h1>

    <!-- 🔍 Search -->
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search doctors by name, specialization, or email..." onkeyup="searchDoctors()">
    </div>
    
    <!-- Doctor Table -->
    <table id="doctorTable">
        <thead>
            <tr>
                <th>Select</th>
                <th>Photo</th>
                <th>Courtesy title</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Specialization</th>
                <th>Qualifications</th>
                <th>Experience</th>
                <th>Reg. No</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <input type="checkbox" 
                                   name="compare" 
                                   value='<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, "UTF-8"); ?>'>
                        </td>
                        <td>
                            <?php if($row['doc_pic']): ?>
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($row['doc_pic']); ?>" width="60" height="60">
                            <?php else: ?>
                                <img src="default_doctor.png" width="60" height="60">
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['courtesy_title']); ?></td>
                        <td><?php echo htmlspecialchars($row['doc_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['doc_email']); ?></td>
                        <td><?php echo htmlspecialchars($row['doc_contactno']); ?></td>
                        <td><?php echo htmlspecialchars($row['doc_DOB']); ?></td>
                        <td><?php echo htmlspecialchars($row['doc_gender']); ?></td>
                        <td><?php echo htmlspecialchars($row['specialization']); ?></td>
                        <td><?php echo htmlspecialchars($row['qualifications']); ?></td>
                        <td><?php echo htmlspecialchars($row['years_experienced']); ?> yrs</td>
                        <td><?php echo htmlspecialchars($row['registration_no']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="12" style="text-align:center;">No doctors found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Compare Button -->
    <div class="compare-btn">
        <button onclick="compareDoctors()">Compare Selected Doctors</button>
    </div>

    <!-- Compare Display -->
    <div id="compareBox" class="compare-box"></div>

    <div class="back-button">
        <a href="admin_dashboard.html">Back to Dashboard</a>
    </div>
</div>

<script>
function searchDoctors() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("#doctorTable tbody tr");

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
}

function compareDoctors() {
    let selected = document.querySelectorAll("input[name='compare']:checked");
    if (selected.length !== 2) {
        alert("Please select exactly 2 doctors to compare.");
        return;
    }

    let compareBox = document.getElementById("compareBox");
    compareBox.innerHTML = "";

    selected.forEach(item => {
        try {
            let data = JSON.parse(item.value);
            let card = `
                <div class="compare-card">
                    ${data.doc_pic ? `<img src="data:image/jpeg;base64,${btoa(atob(data.doc_pic))}">` : `<img src="default_doctor.png">`}
                    <h3>${data.courtesy_title} ${data.doc_name}</h3>
                    <p><b>Email:</b> ${data.doc_email}</p>
                    <p><b>Contact:</b> ${data.doc_contactno}</p>
                    <p><b>DOB:</b> ${data.doc_DOB}</p>
                    <p><b>Gender:</b> ${data.doc_gender}</p>
                    <p><b>Specialization:</b> ${data.specialization}</p>
                    <p><b>Qualifications:</b> ${data.qualifications}</p>
                    <p><b>Experience:</b> ${data.years_experienced} yrs</p>
                    <p><b>Reg No:</b> ${data.registration_no}</p>
                </div>
            `;
            compareBox.innerHTML += card;
        } catch (e) {
            console.error("Invalid JSON in checkbox value", e);
        }
    });
}
</script>

</body>
</html>

<?php
mysqli_close($con);
?>
