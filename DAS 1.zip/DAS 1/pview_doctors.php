<?php
session_start();
include('DBConnection.php');

// Search & sort (your existing logic)
$search = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($con, $_GET['search']);
}
$sort = "doc_name"; 
$order = "ASC";
if (isset($_GET['sort'])) {
    $allowedSort = ['doc_name', 'specialization', 'years_experienced'];
    if (in_array($_GET['sort'], $allowedSort)) $sort = $_GET['sort'];
}
if (isset($_GET['order']) && ($_GET['order'] === "ASC" || $_GET['order'] === "DESC")) $order = $_GET['order'];

$sql = "SELECT doc_name, doc_gender, specialization, years_experienced, registration_no, doc_pic, doctor_Id 
        FROM doctor_details 
        WHERE doc_name LIKE '%$search%' OR specialization LIKE '%$search%'
        ORDER BY $sort $order";
$result = mysqli_query($con, $sql);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Doctors</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container my-4">
  <h1>Available Doctors</h1>

  <form method="get" class="d-flex mb-3 gap-2">
    <input name="search" class="form-control" placeholder="Search" value="<?=htmlspecialchars($search)?>">
    <select name="sort" class="form-select">
      <option value="doc_name" <?= $sort=='doc_name'?'selected':'' ?>>Name</option>
      <option value="specialization" <?= $sort=='specialization'?'selected':'' ?>>Specialization</option>
      <option value="years_experienced" <?= $sort=='years_experienced'?'selected':'' ?>>Experience</option>
    </select>
    <select name="order" class="form-select">
      <option value="ASC" <?= $order=='ASC'?'selected':'' ?>>Asc</option>
      <option value="DESC" <?= $order=='DESC'?'selected':'' ?>>Desc</option>
    </select>
    <button class="btn btn-primary">Search</button>
  </form>

  <div class="d-flex flex-wrap gap-3">
    <?php if ($result && mysqli_num_rows($result) > 0): ?>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="card p-3" style="width:18rem;">
          <div class="text-center mb-2">
            <?php if ($row['doc_pic']): ?>
              <img src="data:image/jpeg;base64,<?=base64_encode($row['doc_pic'])?>" class="rounded-circle" style="width:100px;height:100px;object-fit:cover;">
            <?php else: ?>
              <img src="default_doctor.png" class="rounded-circle" style="width:100px;height:100px;object-fit:cover;">
            <?php endif; ?>
          </div>
          <h5><?=htmlspecialchars($row['doc_name'])?></h5>
          <p class="mb-1"><strong>Spec:</strong> <?=htmlspecialchars($row['specialization'])?></p>
          <p class="mb-1"><strong>Exp:</strong> <?=htmlspecialchars($row['years_experienced'])?> years</p>
          <div class="mt-3">
            <!-- pass doctor_Id from the row -->
            <a href="view_availability.php?doctor_Id=<?=urlencode($row['doctor_Id'])?>" class="btn btn-success">Make Appointment</a>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No doctors found.</p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
<?php mysqli_close($con); ?>
