<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet"  type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <title>footer</title>
    
</head>
<body>
    <footer class="footer">
  <div class="container-footer">
    <div class="row-f">
      <div class="footer_col">
        <h4>QUICK LINKS</h4>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div class="footer_col">
        <h4>CONTACT INFO</h4>
        <ul>
          <li>No.03, Matara Road, Kamburupitiya</li>
          <li>041-229-2222</li>
          <li>071-404-0800</li>
          <li>medcarehealth@gmail.com</li>
        </ul>
      </div>

      <div class="footer_col">
        <h4>FOLLOW US</h4>
        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
      </div>
    </div>

    <div class="copyright">
      <p>&copy; 2025 MedCareHealth. All Rights Reserved.</p>
    </div>
  </div>
</footer>

</body>
</html>









