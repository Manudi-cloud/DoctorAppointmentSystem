<?php
session_start();
include("DBConnection.php");

if (!isset($_SESSION['patient_id'])) {
    die("Please login to view your bookings.");
}

$patient_id = $_SESSION['patient_id'];

$sql = "SELECT lb.booking_id, lb.booking_date, lb.status, lt.test_name, lt.price 
        FROM lab_booking lb
        JOIN labtest_details lt ON lb.test_id = lt.test_id
        WHERE lb.patient_id = ?
        ORDER BY lb.booking_date DESC";

$stmt = $con->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>My Lab Bookings</title>
  <link rel="stylesheet" href="lab_booking.css">

</head>
<body>
<h2>My Lab Bookings</h2>
<table border="1" cellpadding="8">
  <tr><th>Booking ID</th><th>Test</th><th>Price</th><th>Date</th><th>Status</th></tr>
  <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?=htmlspecialchars($row['booking_id'])?></td>
      <td><?=htmlspecialchars($row['test_name'])?></td>
      <td>Rs. <?=number_format($row['price'],2)?></td>
      <td><?=$row['booking_date']?></td>
      <td><?=$row['status']?></td>
    </tr>
  <?php endwhile; ?>
</table>
<a href="patient_dashboard.html">Back to Dashboard</a>
</body>
</html>
