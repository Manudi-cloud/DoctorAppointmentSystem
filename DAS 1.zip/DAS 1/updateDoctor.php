<?php
include("DBConnection.php");

if(isset($_POST['update'])) {
    $doctor_id = intval($_POST['doctor_id']);
    $doc_name = $_POST['doc_name'];
    $doc_email = $_POST['doc_email'];
    $doc_contactno = $_POST['doc_contactno'];
    $specialization = $_POST['specialization'];
    $years_experienced = $_POST['years_experienced'];
    $registration_no = $_POST['registration_no'];

    // Handle optional photo update
    if(isset($_FILES['doctorimage']) && $_FILES['doctorimage']['error'] == 0) {
        $doctor_pic = file_get_contents($_FILES['doctorimage']['tmp_name']);
        $sql = "UPDATE doctor_details SET doc_name=?, doc_email=?, doc_contactno=?, specialization=?, years_experienced=?, registration_no=?, doc_pic=? WHERE doctor_Id=?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssssi", $doc_name, $doc_email, $doc_contactno, $specialization, $years_experienced, $registration_no, $doctor_pic, $doctor_id);
    } else {
        $sql = "UPDATE doctor_details SET doc_name=?, doc_email=?, doc_contactno=?, specialization=?, years_experienced=?, registration_no=? WHERE doctor_Id=?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("ssssssi", $doc_name, $doc_email, $doc_contactno, $specialization, $years_experienced, $registration_no, $doctor_id);
    }

    if($stmt->execute()) {
        echo "<script>alert('Doctor updated successfully'); window.location='doctor_list.php';</script>";
    } else {
        echo "<script>alert('Error: ".$stmt->error."'); history.back();</script>";
    }
    $stmt->close();
}
$con->close();
?>
