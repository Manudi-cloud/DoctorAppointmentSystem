<?php
include("DBConnection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    // ✅ Directly update password by email
    $stmt = $con->prepare("UPDATE patient_details SET password=? WHERE email_address=?");
    $stmt->bind_param("ss", $new_password, $email);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo "Password reset successful! <a href='login.php'>Login Now</a>";
    } else {
        echo "No account found with that email.";
    }

    $stmt->close();
}
?>
