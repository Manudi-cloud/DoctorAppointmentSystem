<?php
session_start();
include("DBConnection.php");

if (isset($_POST['submit'])) {
    $email = trim($_POST['email']);

    // 1. Check if email exists
    $stmt = $con->prepare("SELECT patient_Id FROM patient_details WHERE email_address = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $patient_Id = $row['patient_Id'];

        // Generate secure token 
            if (function_exists('random_bytes')) {
              $token = bin2hex(random_bytes(16));
            } else {
              $token = bin2hex(openssl_random_pseudo_bytes(16));
            }


        // 3. Save token to DB
        $update = $con->prepare("UPDATE patient_details SET reset_token = ? WHERE patient_Id = ?");
        $update->bind_param("si", $token, $patient_Id);
        $update->execute();

        // 4. Build reset link
        $resetLink = "http://localhost/DAS 1/reset_password.php?token=" . $token;

        // Instead of real email, just show the link (for now)
        $_SESSION['msg'] = "Password reset link: <a href='$resetLink'>$resetLink</a>";
    } else {
        $_SESSION['msg'] = "❌ No account found with that email.";
    }

    header("Location: forgot_password.php");
    exit();
}
?>
