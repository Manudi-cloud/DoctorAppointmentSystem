<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="about.css">
    <link rel="icon" type="image/x-icon" href="">

</head>
<body>

    <!--include header -->
    <?php include('header.php');?> 


<!-- about start -->
<div class="about">
        <h1>About Us</h1>
    </div>

<div class="image-row">
    <img src="images/about4.jpg" class="feature-img anim">
    <img src="images/about2.jpg" class="feature-img anim">
</div>


<div class="container-a">
        <div class="section anim">
            <h2 class="anim">Who We Are</h2>
            <p class="anim">MedCare Hospital, a trusted healthcare provider in Kamburupitiya, dedicated to delivering high-quality medical services with compassion and care. To improve accessibility and convenience for our patients, we developed the Online Doctor Appointment Booking System, a digital solution designed to simplify the process of scheduling medical consultations. </div>

        <div class="section anim">
            <h2 class="anim">Our Mission</h2>
            <p class="anim">Our mission is to make healthcare more accessible, efficient, and patient-centered by reducing waiting times, eliminating manual booking challenges, and enhancing communication between patients, doctors, and hospital staff.</div>

        <div class="section anim ">
            <h2 class="anim">Our Vision</h2>
            <p class="anim">We envision a future-ready hospital system where technology bridges the gap between patients and healthcare providers, ensuring seamless appointment scheduling, improved service delivery, and greater patient satisfaction.</div>

        <div class="section anim">
            <h2 class="anim">Our Story</h2>
            <p class="anim">MedCare Hospital has always prioritized patient comfort and service quality. However, with the growing number of patients, the manual appointment booking process led to long queues, overlapping schedules, and miscommunication. To address these challenges, our team collaborated to create a digital platform that allows patients to:
                    Search for doctors by specialization, gender, or experience.View consultation fees and available time slots.Book, reschedule, or cancel appointments easily.Receive real-time confirmations and reminders.

                    This system was born out of our commitment to modernizing healthcare and ensuring that every patient’s journey is smooth from booking to consultation.</div>

        <div class="section anim">
            <h2 class="anim">Our Achievements</h2>
            <p class="anim">Since the launch of the Online Appointment Booking System, we have achieved:

                📈 Reduced average patient waiting time by streamlining scheduling.

                💬 Improved patient satisfaction through clear communication and reminders.

                👩‍⚕️ Better doctor efficiency in managing their schedules.

                🌍 Wider accessibility, as patients can book appointments anytime, from anywhere.

                 This achievement reflects our continuous dedication to innovation and excellence in healthcare services.</div>

        
        </div>

 


 <!--include footer -->
 <?php include('footer.php');?>  


</body>
</html>