<?php
session_start();
include('DBConnection.php');

// Fetch all patient details
$sql = "SELECT patient_Id, name, gender, address, contactnumber, dob, email_address FROM patient_details";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Patients</title>
    <link rel="stylesheet" href="view_Patients.css">
</head>
<body>

<div class="container">
    <h1>Patient Details</h1>
    
    <table class="Patient-table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Contact number</th>
                <th>Date of Birth</th>
                <th>Email Address</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['patient_Id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['gender']); ?></td>
                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                        <td><?php echo htmlspecialchars($row['contactnumber']); ?></td>
                        <td><?php echo htmlspecialchars($row['dob']); ?></td>
                        <td><?php echo htmlspecialchars($row['email_address']); ?></td>
                        
                        
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="11" style="text-align:center;">No doctors found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="back-button">
        <a href="admin_dashboard.html">Back to Dashboard</a>
    </div>
</div>

</body>
</html>

<?php
mysqli_close($con);
?>
