<?php
session_start();
include("DBConnection.php");

// Get logged-in doctor ID from session
if (!isset($_SESSION['doctor_id'])) {
    die("Unauthorized access. Please login first.");
}

$doctor_id = $_SESSION['doctor_id'];

// Get form values
$available_date = $_POST['available_date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];

// Insert into database
$stmt = $con->prepare("INSERT INTO doctor_availabiility (doctor_id, available_date, start_time, end_time) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isss", $doctor_id, $available_date, $start_time, $end_time);

if ($stmt->execute()) {
    header("Location: doctor_dashboard.php?success=1");
    exit;
} else {
    echo "Error: " . $stmt->error;
}
?>
