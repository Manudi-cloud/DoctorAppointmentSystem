<?php
session_start();
include("DBConnection.php");

// Check login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['login'];
$msg = $error = "";

// Fetch user details
$stmt = $con->prepare("SELECT name, gender, address, contactnumber, dob, email_address, username FROM patient_details WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($name, $gender, $address, $contact, $dob, $email, $user);
$stmt->fetch();
$stmt->close();

// Handle update submission
if (isset($_POST['update'])) {
    $newName = $_POST['txtname'];
    $newGender = $_POST['txtgender'];
    $newAddress = $_POST['txtaddress'];
    $newContact = $_POST['txtcontact'];
    $newDOB = $_POST['txtDOB'];
    $newEmail = $_POST['txtemail'];

    $stmt = $con->prepare("UPDATE patient_details SET name=?, gender=?, address=?, contactnumber=?, dob=?, email_address=? WHERE username=?");
    $stmt->bind_param("sssssss", $newName, $newGender, $newAddress, $newContact, $newDOB, $newEmail, $username);

    if ($stmt->execute()) {
        $msg = "Profile updated successfully!";
        // refresh displayed values
        $name = $newName;
        $gender = $newGender;
        $address = $newAddress;
        $contact = $newContact;
        $dob = $newDOB;
        $email = $newEmail;
    } else {
        $error = "Error updating profile.";
    }
    $stmt->close();
}
$con->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link rel="stylesheet" href="profile.css">
    

</head>
<body>
    <div class="profile-container">
        <h2>My Profile</h2>

        <!-- Show alerts if needed -->
        <?php if ($msg): ?>
            <script>alert("<?= $msg ?>");</script>
        <?php endif; ?>
        <?php if ($error): ?>
            <script>alert("<?= $error ?>");</script>
        <?php endif; ?>

        <!-- READ-ONLY VIEW -->
        <div id="viewMode" class="readonly-view">
            <p><strong>Name:</strong> <?= htmlspecialchars($name) ?></p>
            <p><strong>Gender:</strong> <?= htmlspecialchars($gender) ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($address) ?></p>
            <p><strong>Contact:</strong> <?= htmlspecialchars($contact) ?></p>
            <p><strong>DOB:</strong> <?= htmlspecialchars($dob) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($email) ?></p>

        </div>

        <!-- EDIT FORM (HIDDEN INITIALLY) -->
        <form id="editMode" method="post" class="hidden">
            <label>Name</label>
            <input type="text" name="txtname" value="<?= $name ?>" required><br>

            <label>Gender</label>
            <input type="text" name="txtgender" value="<?= $gender ?>" required><br>

            <label>Address</label>
            <input type="text" name="txtaddress" value="<?= $address ?>" required><br>

            <label>Contact</label>
            <input type="text" name="txtcontact" value="<?= $contact ?>" required><br>

            <label>DOB</label>
            <input type="date" name="txtDOB" value="<?= $dob ?>" required><br>

            <label>Email</label>
            <input type="email" name="txtemail" value="<?= $email ?>" required><br>

            <button type="submit" name="update">Update Profile</button>
            <button type="button" class="back-button" onclick="window.location.href='patient_dashboard.html'"> Back to Dashboard</button>

        </form>
    </div>


    <script>
        function toggleEdit(isEdit) {
            document.getElementById('viewMode').classList.toggle('hidden', isEdit);
            document.getElementById('editMode').classList.toggle('hidden', !isEdit);
        }
    </script>

    
</body>
</html>
