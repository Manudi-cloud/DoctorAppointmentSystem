<?php
session_start(); 
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login_New.css">
    <link rel="icon" type="image/x-icon" href="./images/icon2.ico">

</head>
<body>
    <div class="form-container">
        <div class="login-box">
            <form id="form1" name="form1" method="post" action="userChecking.php">
                <fieldset>
                    <legend>Login</legend>
                    <div class="form-group">
                        <label for="txtusername" style="color: #000000">Username:</label>
                        <input name="txtusername" type="text" id="txtusername" required>
                    </div>
                    <div class="form-group">
                        <label for="txtpswd" style="color: #000000">Password:</label>
                        <input name="txtpswd" type="password" id="txtpswd" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="btnlogin" id="btnlogin" value="Login" class="btnlogin">
                    </div>

                    <div class="form-group">
                        <p style="text-align: center; margin-top: 10px;">
                           <a href="forgot_password.php" style="color: blue; text-decoration: underline;">Forgot Password?</a>
                        </p>
                    </div>

                    <div class="form-group">
                        <p>
                        <input type="button" name="btnNewAccount" id="btnNewAccount" value="Create New Account" class="btnlogin" onclick="window.location.href='register.php'">
                        </p>
                    </div>
                </fieldset>
            </form>

            <?php 
            // 🚨 Error alert
            if (isset($_SESSION['error']) && !empty($_SESSION['error'])) {
                echo "<script>
                        Swal.fire({
                            icon: 'error',
                            title: 'Login Failed',
                            text: '".addslashes($_SESSION['error'])."',
                            confirmButtonColor: '#3498db'
                        });
                      </script>";
                unset($_SESSION['error']); 
            } 
            
            // 🎉 Success alert + redirect
            if (isset($_SESSION['success']) && !empty($_SESSION['success'])) {
                // detect role from cookie
                $role = isset($_COOKIE['log']) ? $_COOKIE['log'] : '';

                $redirect = "login.php"; // fallback
                if ($role === "admin") {
                    $redirect = "admin_dashboard.html";
                } elseif ($role === "patient") {
                    $redirect = "patient_dashboard.html";
                } elseif ($role === "doctor") {
                    $redirect = "doctor_dashboard.php";
                }

                echo "<script>
                        Swal.fire({
                            icon: 'success',
                            title: 'Login Successful',
                            text: '".addslashes($_SESSION['success'])."',
                            confirmButtonColor: '#3498db'
                        }).then(() => {
                            window.location.href = '$redirect';
                        });
                      </script>";
                unset($_SESSION['success']); 
            }
            ?>
        </div>
    </div>
</body>
</html>
