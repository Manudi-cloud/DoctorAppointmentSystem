<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link rel="icon" type="image/x-icon" href="">
    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
       


     

        /* Container for gallery */

        .title-container {
        text-align: center;
        padding: 50px 20px 10px;
        background: #006d77;
        color: #fff;
    
}


.title-container h1 {
    font-size: 2.5em;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

}

        .img-gallery-g {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            padding: 30px;
            margin: 0 auto;
            max-width: 1200px;
           margin-top: 50px;
           padding-top: 50px;
           padding-bottom: 40px;
           margin-bottom: 50px;
        }

        /* Styling for each image in the gallery */
        .img-gallery-g img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .img-gallery-g img:hover {
            transform: scale(1.05);
            box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.4);
        }

        /* Styling for responsiveness */
        @media (max-width: 768px) {
            .img-gallery-g {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                padding: 20px;
            }
        }

        @media (max-width: 480px) {
            .img-gallery-g {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                padding: 10px;
            }
        }



        
    </style>
</head>
<body>

<!-- Include header -->
<?php include('header.php'); ?>


<div class="title-container">
        <h1>Gallery</h1>
    </div>

<!-- Image gallery container -->
<div class="img-gallery-g">
    <img src="images/g1.jpg" alt="Gallery Image 1">
    <img src="images/g2.jpg" alt="Gallery Image 2">
    <img src="images/g3.jpg" alt="Gallery Image 3">
    <img src="images/g4.jpg" alt="Gallery Image 4">
    <img src="images/g5.jpg" alt="Gallery Image 5">
    <img src="images/g6.jpg" alt="Gallery Image 6">
    <img src="images/g7.jpg" alt="Gallery Image 7">
    <img src="images/g8.jpg" alt="Gallery Image 8">
    <img src="images/g9.jpg" alt="Gallery Image 9">
    <img src="images/g10.jpg" alt="Gallery Image 10">
    <img src="images/g11.jpg" alt="Gallery Image 11">
    <img src="images/g12.jpg" alt="Gallery Image 12">
    <img src="images/g13.jpg" alt="Gallery Image 13">
    <img src="images/g14.jpg" alt="Gallery Image 14">
    <img src="images/g15.jpg" alt="Gallery Image 15">
    <img src="images/g16.jpg" alt="Gallery Image 16">
    <img src="images/g17.jpg" alt="Gallery Image 17">
    <img src="images/g18.jpg" alt="Gallery Image 18">
    <img src="images/g19.jpg" alt="Gallery Image 19">
    <img src="images/g20.jpg" alt="Gallery Image 20">
    <img src="images/g21.jpg" alt="Gallery Image 21">
    <img src="images/g22.jpg" alt="Gallery Image 22">
    <img src="images/g23.jpg" alt="Gallery Image 23">
    <img src="images/g24.jpg" alt="Gallery Image 24">
</div>

<!-- Include footer -->
<?php include('footer.php'); ?>

</body>
</html>