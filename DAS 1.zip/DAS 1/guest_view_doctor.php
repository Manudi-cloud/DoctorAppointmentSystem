<?php
session_start();
include('DBConnection.php');

// Initialize search query
$search = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($con, $_GET['search']);
}

// Initialize sorting
$sort = "doc_name"; 
$order = "ASC";     
if (isset($_GET['sort'])) {
    $allowedSort = ['doc_name', 'specialization', 'years_experienced'];
    if (in_array($_GET['sort'], $allowedSort)) {
        $sort = $_GET['sort'];
    }
}
if (isset($_GET['order']) && ($_GET['order'] === "ASC" || $_GET['order'] === "DESC")) {
    $order = $_GET['order'];
}

// Fetch doctor details with search + sort
$sql = "SELECT doc_name, doc_gender, specialization, years_experienced, registration_no, doc_pic, doctor_Id 
        FROM doctor_details 
        WHERE doc_name LIKE '%$search%' OR specialization LIKE '%$search%'
        ORDER BY $sort $order";

$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="pview_doctors.css">
</head>
<body>

<div class="container my-4">
    <h1 class="mb-4">Available Doctors</h1>

    <!-- Search + Sort -->
    <form method="get" action="" class="d-flex mb-4 gap-2">
        <input type="text" name="search" class="form-control" placeholder="Search by doctor name or specialization" 
               value="<?php echo htmlspecialchars($search); ?>">

        <select name="sort" class="form-select">
            <option value="doc_name" <?php if($sort=="doc_name") echo "selected"; ?>>Sort by Name</option>
            <option value="specialization" <?php if($sort=="specialization") echo "selected"; ?>>Sort by Specialization</option>
            <option value="years_experienced" <?php if($sort=="years_experienced") echo "selected"; ?>>Sort by Experience</option>
        </select>

        <select name="order" class="form-select">
            <option value="ASC" <?php if($order=="ASC") echo "selected"; ?>>Ascending</option>
            <option value="DESC" <?php if($order=="DESC") echo "selected"; ?>>Descending</option>
        </select>

        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <!-- Doctor Cards -->
    <div class="doctor-cards d-flex flex-wrap gap-3">
        <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="doctor-card card shadow-sm p-3" style="width: 18rem;">
                    <div class="doctor-image text-center mb-3">
                        <?php if($row['doc_pic']): ?>
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($row['doc_pic']); ?>" 
                                 alt="Doctor Photo" class="img-fluid rounded-circle" style="width:100px; height:100px; object-fit:cover;">
                        <?php else: ?>
                            <img src="default_doctor.png" alt="No Photo" class="img-fluid rounded-circle" style="width:100px; height:100px; object-fit:cover;">
                        <?php endif; ?>
                    </div>
                    <div class="doctor-info text-center">
                        <h5><?php echo htmlspecialchars($row['doc_name']); ?></h5>
                        <p class="mb-1"><strong>Specialization:</strong> <?php echo htmlspecialchars($row['specialization']); ?></p>
                        <p class="mb-1"><strong>Experience:</strong> <?php echo htmlspecialchars($row['years_experienced']); ?> years</p>
                        <p class="mb-0"><strong>Gender:</strong> <?php echo htmlspecialchars($row['doc_gender']); ?></p>
                    </div>
                    <!-- Booking button -->
                    <div class="back-button mt-4">
                       <a href="login.php" class="btn btn-secondary">Make Appointment</a>
                    </div>
                </div>
                
            <?php endwhile; ?>
        <?php else: ?>
            <p>No doctors found.</p>
        <?php endif; ?>
    </div>

    

    <!-- Back button -->
    <div class="back-button mt-4">
        <a href="patient_dashboard.html" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</div>

</body>
</html>

<?php
mysqli_close($con);
?>
