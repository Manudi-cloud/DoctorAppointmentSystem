<?php
session_start();
include("DBConnection.php");

if (!isset($_GET['appointment_Id'])) {
    die("Invalid appointment.");
}

$appointment_id = intval($_GET['appointment_Id']);

$sql = "SELECT a.appointment_Id, a.status, d.doc_name, av.available_date, av.start_time, av.end_time,
               p.method, p.status AS payment_status, p.created_at AS payment_time
        FROM appointment a
        JOIN doctor_details d ON a.doctor_Id = d.doctor_Id
        JOIN doctor_availabiility av ON a.availability_id = av.id
        JOIN payment p ON a.appointment_Id = p.appointment_Id
        WHERE a.appointment_Id = ?
        ORDER BY p.created_at DESC
        LIMIT 1";

$stmt = $con->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $con->error);
}
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();
$appointment = $result->fetch_assoc();

if (!$appointment) {
    die("Invalid appointment.");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Payment Success</title>
</head>
<body>
  <h2>Payment Successful</h2>
  <p><strong>Appointment Number:</strong> <?php echo $appointment['appointment_Id']; ?></p>
  <p><strong>Doctor:</strong> <?php echo $appointment['doc_name']; ?></p>
  <p><strong>Date:</strong> <?php echo $appointment['available_date']; ?></p>
  <p><strong>Time:</strong> <?php echo $appointment['start_time'] . " - " . $appointment['end_time']; ?></p>
  <p><strong>Appointment Status:</strong> <?php echo $appointment['status']; ?></p>
  <p><strong>Payment Method:</strong> <?php echo $appointment['method']; ?></p>
  <p><strong>Payment Status:</strong> <?php echo $appointment['payment_status']; ?></p>
  <p><strong>Payment Time:</strong> <?php echo $appointment['payment_time']; ?></p>

  <div class="back-button">
     <a href="patient_dashboard.html">Back</a>
  </div>
</body>
</html>

