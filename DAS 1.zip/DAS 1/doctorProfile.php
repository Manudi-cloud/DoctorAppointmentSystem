<?php
session_start();
include("DBConnection.php");

// Make sure doctor is logged in
if (!isset($_SESSION['doctor_id'])) {
    header("Location: login.php");
    exit;
}

$doctorId = $_SESSION['doctor_id'];

// Fetch doctor details
$sql = "SELECT courtesy_title, doc_name, doc_email, doc_contactno, doc_DOB, doc_gender, specialization, qualifications, years_experienced, registration_no, doc_pic 
        FROM doctor_details WHERE doctor_Id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $doctorId);
$stmt->execute();
$stmt->bind_result($courtesy_title, $doc_name, $doc_email, $doc_contactno, $doc_DOB, $doc_gender, $specialization, $qualifications, $years_experienced, $registration_no, $doc_pic);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Doctor Profile</title>
    <style>
        body { font-family: Arial; }
        .profile-container { width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; }
        img { width: 120px; height: 120px; object-fit: cover; border-radius: 60px; }
        label { display: block; margin-top: 10px; }
        input, select { width: 100%; padding: 6px; margin-top: 5px; }
        button { margin-top: 15px; padding: 10px 20px; }
    </style>
</head>
<body>
<div class="profile-container">
    <h2>Welcome, <?= htmlspecialchars($doc_name) ?></h2>

    <?php if ($doc_pic): ?>
        <img src="data:image/jpeg;base64,<?= base64_encode($doc_pic) ?>" alt="Doctor Photo">
    <?php else: ?>
        <p>No photo uploaded.</p>
    <?php endif; ?>

    <form method="post" action="deditDoctor.php" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $doctorId ?>">

        <label>Courtesy Title:</label>
        <select name="courtesy_title" required>
            <option value="Mr" <?= $courtesy_title=="Mr"?"selected":"" ?>>Mr</option>
            <option value="Mrs" <?= $courtesy_title=="Mrs"?"selected":"" ?>>Mrs</option>
            <option value="Ms" <?= $courtesy_title=="Ms"?"selected":"" ?>>Ms</option>
            <option value="Prof" <?= $courtesy_title=="Prof"?"selected":"" ?>>Prof</option>
        </select>

        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($doc_name) ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($doc_email) ?>" required>

        <label>Contact No:</label>
        <input type="text" name="contact" value="<?= htmlspecialchars($doc_contactno) ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="dob" value="<?= htmlspecialchars($doc_DOB) ?>" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option value="Male" <?= $doc_gender=="Male"?"selected":"" ?>>Male</option>
            <option value="Female" <?= $doc_gender=="Female"?"selected":"" ?>>Female</option>
        </select>

        <label>Specialization:</label>
        <input type="text" name="specialization" value="<?= htmlspecialchars($specialization) ?>" required>

        <label>Qualifications:</label>
        <input type="text" name="qualifications" value="<?= htmlspecialchars($qualifications) ?>" required>

        <label>Experience (years):</label>
        <input type="number" name="experience" value="<?= htmlspecialchars($years_experienced) ?>" required>

        <label>Registration No:</label>
        <input type="text" name="reg_no" value="<?= htmlspecialchars($registration_no) ?>" required>

        <label>Update Photo:</label>
        <input type="file" name="doctorimage" accept="image/*">

        <button type="submit" name="update">Update Profile</button>
    </form>
</div>
</body>
</html>
