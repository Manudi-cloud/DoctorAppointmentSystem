<?php
session_start();
include("DBConnection.php");

if (!isset($_GET['doctor_Id'])) {
    die("Doctor not specified.");
}
$doctor_Id = intval($_GET['doctor_Id']);

$stmt = $con->prepare("SELECT id, available_date, start_time, end_time 
                       FROM doctor_availabiility 
                       WHERE doctor_Id = ? 
                       ORDER BY available_date, start_time");
if (!$stmt) die("SQL Error: " . $con->error);
$stmt->bind_param("i", $doctor_Id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Availability</title></head><body>
  <h2>Available Time Slots</h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <table border="1" cellpadding="8">
      <tr><th>Date</th><th>Start</th><th>End</th><th>Action</th></tr>
      <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($row['available_date'])?></td>
        <td><?=htmlspecialchars($row['start_time'])?></td>
        <td><?=htmlspecialchars($row['end_time'])?></td>
        <td>
          <form method="post" action="appointment.php">
            <input type="hidden" name="availability_id" value="<?=intval($row['id'])?>">
            <input type="hidden" name="doctor_id" value="<?=intval($doctor_Id)?>">
            <button type="submit">Book</button>
          </form>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No availability found for this doctor.</p>
  <?php endif; ?>
</body></html>
