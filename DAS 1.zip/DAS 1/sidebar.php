<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Official Website </title>


    
</head>
<body>
<!-- Sidebar -->
  <div class="sidebar">
    <ul class="nav flex-column gap-2 px-3">
      <li><a href="patient_dashboard.html" class="nav-link active"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
      <li><a href="profile.php" class="nav-link"><i class="bi bi-person-circle me-2"></i> Profile</a></li>
      <li><a href="#" class="nav-link"><i class="bi bi-calendar-event me-2"></i> Appointments</a></li>
      <li><a href="#" class="nav-link"><i class="bi bi-graph-up me-2"></i> Analytics</a></li>
      <li><a href="pview_doctors.php" class="nav-link"><i class="bi bi-heart-pulse me-2"></i> Doctors</a></li>
      <li><a href="#" class="nav-link"><i class="bi bi-file-earmark-text me-2"></i> Reports</a></li>
      <li><a href="#" class="nav-link"><i class="bi bi-bell me-2"></i> Notifications</a></li>
      <li><a href="#" class="nav-link"><i class="bi bi-question-circle me-2"></i> Help</a></li>
      <li><a href="logout.php" class="nav-link text-danger"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
    </ul>
  </div>
</body>
</html>