<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Official Website</title>
    <link rel="icon" type="image/x-icon" href="./images/icon2.ico">
    <link rel="stylesheet" href="index.css">
    <style>
        /* General Reset */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: "Segoe UI", Arial, sans-serif;
  line-height: 1.6;
  background: #f4f8fb;
  color: #333;
}

/* ================= HEADER ================= */
header {
  background: #002244; 
  color: #fff;
  padding: 10px 0;
  box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

.container-header {
  width: 90%;
  max-width: 1200px;
  margin: auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  width: 80px;
}

nav ul {
  list-style: none;
  display: flex;
}

nav ul li {
  margin-left: 20px;
}

nav ul li a {
  color: #fff; /* White nav text */
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}

nav ul li a:hover {
  color: #00c3ff;
}

/* ================= SLIDESHOW ================= */
.slideshow-container {
  position: relative;
  width: 100%;
  height: 100vh;      /* take full viewport height */
  margin: 0;
  overflow: hidden;
}

.slideshow-container img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;   /* fills screen */
  display: none;
}

.slideshow-container img.active {
  display: block;
  animation: fade 1s;
}



@keyframes fade {
  from {opacity: 0.4;}
  to {opacity: 1;}
}

/* Welcome text overlay on slideshow */
.welcome-overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  text-align: center;
  z-index: 10;
}

.welcome-overlay h3 {
  font-size: 28px;
  font-weight: 400;
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 2px;
}

.welcome-overlay h1 {
  font-size: 60px;
  font-weight: bold;
  margin-bottom: 15px;
  text-shadow: 2px 2px 10px rgba(0,0,0,0.6);
}

.welcome-overlay p {
  font-size: 20px;
  font-style: italic;
  background: rgba(0, 0, 0, 0.4);
  display: inline-block;
  padding: 8px 20px;
  border-radius: 6px;
}

/* ================= FEATURES ================= */
.features {
  padding: 60px 20px;
  text-align: center;
  background: #fff;
}

.features h2 {
  font-size: 28px;
  color: #002244;
  margin-bottom: 40px;
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 30px;
}

.feature {
  background: #f4f8fb;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s;
}

.feature:hover {
  transform: translateY(-6px);
}

.feature h3 {
  font-size: 18px;
  margin-bottom: 10px;
  color: #007BFF;
}

.feature p {
  font-size: 14px;
  color: #555;
}

/*=================Review====================*/
.section_container {
    max-width: 1200px;
    margin: auto;
    padding: 2rem 1rem;
    text-align: center;
    font-family: "poppins", sans-serif;
    margin-bottom: 40px;
}

.section_container h2 {
    font-size: 1.5rem;
    font-weight: 600;
    color: #149e9e;
}

.section_container h1 {
    position: relative;
    margin-bottom: 2rem;
    font-size: 2.5rem;
    font-weight: 600;
    color: #0f172a;
}

.section_container h1::after {
    position: absolute;
    content: "";
    left: 50%;
    bottom: -4px;
    transform: translateX(-50%);
    height: 2px;
    width: 10rem;
    background-color: #149e9e;
}

.section_grid {
    display: flex;
    gap: 2rem;
    margin: 0 -15px;
    margin-bottom: 20px;
   
} 

.section_card {
    position: relative;    
    isolation: isolate;
    overflow: hidden;
    padding: 5rem 2rem 2rem;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1);
    transition: 0.3s;
    height: 400px;
    width: 250px;
    margin-right: 15px;
    margin-bottom: 30px;
   

}

.section_card ::before {
    position: absolute;
    content: "";
    top: 0;
    left: 0;
    transform: translate(-50%, -50%);
    width: 75%;
    aspect-ratio: 1;
    border-radius: 100%;
    background-color: #149e9e;
    z-index: -1;
    transition: 0.5s;
} 


.section_card h4 {
    margin-top: 3rem;
    margin-bottom: 1rem;
    font-size: 1.5rem;
    font-weight: 600;
    color: #149e9e;
    transition: 0.3s;
}

.section_card p {
    margin-bottom: 2rem;
    color: #94a3b8;
    transition: 0.3s;
}

.section_card img {
    display: block;
    width: 100px;
    height: 100px;
    margin-bottom: 0.5rem;
    border-radius: 50%;
    border: 3px solid #149e9e;
    object-fit: cover;
    transition: 0.3s;
    margin: 0 auto 1rem; /* Ensures image is horizontally centered */
}

.section_card h5 {
    font-size: 1.25rem;
    font-weight: 600;
    color: #149e9e;
    transition: 0.3s;
}


.section_card :hover::before {
    width: 400%;
}
.section_card:hover :is(h4, h5) {
    color: #fff;
}

.section_card:hover :is(p) {
    color: #e8e8e8;
}
.section_card:hover img {
    border-color: #fff;
}

.slick-dots {
  
    bottom: -35px;
}

/* ================= FACILITIES ================= */
.facilities-section {
  padding: 60px 20px;
  background: #f9fcff;
  text-align: center;
}

.facilities-section .title {
  font-size: 32px;
  color: #002244;
  margin-bottom: 10px;
}

.facilities-section .subtitle {
  font-size: 16px;
  color: #666;
  margin-bottom: 40px;
}

.facility {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 40px;
  max-width: 900px;
  margin-left: auto;
  margin-right: auto;
  gap: 20px;
}

.facility img {
  width: 300px;
  height: 200px;
  border-radius: 12px;
  object-fit: cover;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.facility .info {
  text-align: left;
  max-width: 500px;
}

.facility .info h2 {
  font-size: 22px;
  color: #007BFF;
  margin-bottom: 10px;
}

.facility .info p {
  font-size: 15px;
  color: #555;
}

/* Alternate layout (image left, image right) */
.facility:nth-child(even) {
  flex-direction: row-reverse;
}

/* ================= LAB SERVICES ================= */
.lab-title {
  text-align: center;
  padding: 50px 20px 20px;
}

.lab-title h1 {
  font-size: 32px;
  color: #002244;
  margin-bottom: 10px;
}

.lab-title p {
  font-size: 16px;
  color: #666;
}

.lab-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 25px;
  padding: 40px 20px;
  max-width: 1200px;
  margin: auto;
}

.lab-card {
  background: #fff;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.08);
  text-align: center;
  transition: transform 0.3s ease;
}

.lab-card:hover {
  transform: translateY(-6px);
}

.lab-card img {
  width: 100%;
  height: 180px;
  border-radius: 10px;
  object-fit: cover;
  margin-bottom: 15px;
}

.lab-card h2 {
  font-size: 20px;
  color: #007BFF;
  margin-bottom: 10px;
}

.lab-card p {
  font-size: 14px;
  color: #555;
}


/* ================= FOOTER ================= */
.footer {
  background: #002244;
  color: #fff;
  padding: 40px 0 20px;
  margin-top: 50px;
}

    </style>
</head>
<body>

    <!-- Include header -->
    <?php include('header.php');?> 

    <!-- Slideshow -->
    <div class="slideshow-container">
        <img src="images/bg13new.jpg" class="active" >
        <img src="images/bg20.jpg" alt="Hospital" >
        <img src="images/bg3.jpg" alt="Hospital" >
        <img src="images/bg2.jpg" alt="Hospital">
        <img src="images/bg4.jpg" alt="Hospital">
        <img src="images/bg5.jpg" alt="Hospital">
        <img src="images/bg6.jpg" alt="Hospital">
        <img src="images/bg14.jpg"  alt="Hospital">

        <!-- Welcome text overlay -->
        <div class="welcome-overlay">
            <h3>Welcome to</h3>
            <h1>MedCare Hospital</h1>
            <p>Patient-Centered. Trusted Care. Modern Excellence.</p>
        </div>
    </div>

    <!--Faciities-->

    <div class="facilities-section">
    <h1 class="title">Our Facilities</h1>
    <p class="subtitle">We provide a wide range of healthcare services to support your wellness journey.</p>

    <div class="facility">
      <img src="images/facility1.jpg" alt="Doctor Appointments">
      <div class="info">
        <h2>Doctor Appointments</h2>
        <p>Book appointments with experienced doctors easily through our system.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility2.jpg" alt="Lab Tests">
      <div class="info">
        <h2>Laboratory Tests</h2>
        <p>Get accurate and fast lab tests including blood, urine, scans, and more.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility3.jpg" alt="Pharmacy">
      <div class="info">
        <h2>Pharmacy</h2>
        <p>Order prescribed medicines online and collect them at your convenience.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility4.jpg" alt="Emergency">
      <div class="info">
        <h2>Emergency Care</h2>
        <p>24/7 emergency services with quick access to doctors and specialists.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility5.jpg" alt="Health Records">
      <div class="info">
        <h2>Health Records</h2>
        <p>Securely store and manage your health reports and prescriptions online.</p>
      </div>
    </div>

    <div class="facility">
      <img src="images/facility6.jpg" alt="Support">
      <div class="info">
        <h2>Customer Support</h2>
        <p>Our team is here to help with any queries about your healthcare needs.</p>
      </div>
    </div>
  </div>
   <!-- Title Section -->
  <div class="lab-title">
    <h1>Laboratory Services</h1>
    <p>Accurate, reliable, and fast diagnostic testing for better healthcare decisions.</p>
  </div>

  <!-- Services Section -->
  <div class="lab-container">
    <div class="lab-card">
      <img src="images/lab1.jpg" alt="Blood Test">
      <h2>Blood Tests</h2>
      <p>Comprehensive blood analysis including CBC, sugar levels, cholesterol, and more for accurate diagnosis.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab2.jpg" alt="X-Ray">
      <h2>X-Ray Imaging</h2>
      <p>High-quality digital X-rays for quick and precise detection of bone and chest conditions.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab3.jpg" alt="Scan">
      <h2>Scans & Ultrasound</h2>
      <p>Modern ultrasound and scanning facilities to ensure effective and safe medical imaging.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab4.jpg" alt="Urine Test">
      <h2>Urine Tests</h2>
      <p>Routine and advanced urine analysis to assist in the diagnosis of infections and other conditions.</p>
     
    </div>

    <div class="lab-card">
      <img src="images/lab5.jpg" alt="ECG">
      <h2>ECG (Electrocardiogram)</h2>
      <p>Non-invasive test to measure heart rhythms and detect cardiac conditions.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab6.jpg" alt="MRI">
      <h2>MRI Scans</h2>
      <p>Advanced magnetic imaging for detailed internal organ, brain, and spine analysis.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab7.jpg" alt="Allergy Testing">
      <h2>Allergy Testing</h2>
      <p>Identify common food, pollen, dust, and skin allergies through modern lab testing.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab8.jpg" alt="Liver Function">
      <h2>Liver & Kidney Function Tests</h2>
      <p>Comprehensive panels to monitor liver enzymes and kidney health indicators.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab9.jpg" alt="Hormone Test">
      <h2>Hormone & Thyroid Tests</h2>
      <p>Accurate analysis of hormone levels to diagnose thyroid and endocrine disorders.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab10.jpg" alt="COVID-19 Test">
      <h2>COVID-19 / PCR Tests</h2>
      <p>Reliable PCR and rapid antigen testing for COVID-19 detection and travel requirements.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab11.jpg" alt="Vitamin Test">
      <h2>Vitamin & Mineral Tests</h2>
      <p>Check essential vitamins like Vitamin D, B12, iron, and minerals to maintain good health.</p>
      
    </div>

    <div class="lab-card">
      <img src="images/lab12.jpg" alt="DNA Test">
      <h2>DNA & Genetic Testing</h2>
      <p>Advanced genetic screening for inherited disorders, ancestry, and personalized medicine.</p>
      
    </div>

    </div>

  </div>
  
    <!-- Highlights Section -->
    <section class="features">
        <h2>Why Choose MedCare?</h2>
        <div class="feature-grid">
            <div class="feature">
                <h3>👨‍⚕️ Expert Doctors</h3>
                <p>Our highly qualified doctors provide personalized and compassionate care.</p>
            </div>
            <div class="feature">
                <h3>🏥 Modern Facilities</h3>
                <p>State-of-the-art equipment and advanced medical technology.</p>
            </div>
            <div class="feature">
                <h3>💊 24/7 Pharmacy</h3>
                <p>Always open to ensure patients have access to medicines anytime.</p>
            </div>
            <div class="feature">
                <h3>🚑 Emergency Support</h3>
                <p>Round-the-clock ambulance and emergency services available.</p>
            </div>
        </div>
    </section>

    <div class="slideshow-container">
    <video autoplay muted loop>
        <source src="images/video6.mp4" type="video/mp4">
    </video>
    <video autoplay muted loop>
        <source src="images/video2.mp4" type="video/mp4">
    </video>
    <video autoplay muted loop>
        <source src="images/video5.mp4" type="video/mp4">
    </video>
    <video autoplay muted loop>
        <source src="images/video8.mp4" type="video/mp4">
    </video>
    </div>

    <!-- Customer Reviews -->
    <section class="section_container">
        <h2>Testimonials</h2>
        <h1>What Our Patients Say</h1> 
        <div class="section_grid" id="reviewsContainer">
            <?php
            // Include database connection
            include('DBConnection.php');

            // Fetch reviews
            $reviews = [];
            $sql = "SELECT patient_Name, review_brief, review_detail FROM tblreview";
            $result = mysqli_query($con, $sql);
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $reviews[] = $row;
                }
            }
            mysqli_close($con);

            // Display reviews
            if (!empty($reviews)): 
                foreach ($reviews as $review): ?>
                    <div class="review_card">
                        <h3><?php echo htmlspecialchars($review['patient_Name']); ?></h3>
                        <p><strong><?php echo htmlspecialchars($review['review_brief']); ?></strong></p>
                        <p><?php echo nl2br(htmlspecialchars($review['review_detail'])); ?></p>
                    </div>
                <?php endforeach; 
            else: ?>
                <p>No reviews available.</p>
            <?php endif; ?>
        </div>
    </section>

    <script>
    let slideIndex = 0;
    const slides = document.querySelectorAll(".slideshow-container img");

    function showSlides() {
      slides.forEach(slide => slide.classList.remove("active"));
  
      slideIndex++;
      if (slideIndex > slides.length) { slideIndex = 1; }

      slides[slideIndex - 1].classList.add("active");

      setTimeout(showSlides, 4000); // 4 seconds per slide
    }

    showSlides();
    </script>


    <!-- Include footer -->
    <?php include ('footer.php');?>

    
</body>
</html>
