<?php
include('DBConnection.php'); 

$error = '';
$msg = '';

if (isset($_POST['submit'])) {
    // Collect form data
    $fname = $_POST['txtFname'];
    $uemail = $_POST['txtemail'];
    $contact = $_POST['txtcontactno'];
    $uname = $_POST['txtUname'];
    $upswd = $_POST['txtpswd'];
    $upassword = $_POST['txtpswd2'];


    // Check if passwords match
    if ($upswd !== $upassword) {
        $error = "Passwords do not match.";
    } else {
        // Check for existing email or username
        $stmt = $con->prepare("SELECT COUNT(*) FROM admin_details WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $uemail, $uname);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            $error = "Email or Username already exists.";
        } else {
            // Prepare and bind for insertion
            $stmt = $con->prepare("INSERT INTO admin_details (name, email, contactno, username, password) VALUES (?, ?, ?, ?, ?)");
            
            if ($stmt) {
                // Bind parameters
                $stmt->bind_param("sssss", $fname, $uemail, $contact, $uname, $upswd);

                // Execute the statement
                if ($stmt->execute()) {
                    $msg = "Successfully Added New Admin";
                } else {
                    $error = "Something went wrong. Please try again.";
                }
                
                // Close the statement
                $stmt->close();
            } else {
                $error = "Failed to prepare statement.";
            }
        }
    }
}

// Close the database connection
$con->close(); 
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>New Admin</title>
    <link rel="icon" type="image/x-icon" href="../Pages/images/logo new.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <link rel="stylesheet" href="new_Admin.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        function showError(msg) {
            swal("Error!", msg, "error");
        }

        function showMessage(msg) {
            swal("Success!", msg, "success");
        }

        function validateForm() {
            var password = document.getElementById("txtpswd").value;
            var confirmPassword = document.getElementById("txtpswd2").value;
            if (password !== confirmPassword) {
                showError("Passwords do not match.");
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }
    </script>
    
</head>
<body>
    
    <!--include header -->
    <?php include('header.php');?> 

    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a> New Admin</li>
                </ol>
                <div class="grid-form">
                    <div class="grid-form1">
                        <h3>Add New Admin</h3>
                        <form class="form-horizontal" name="package" method="post" enctype="multipart/form-data" onsubmit="return validateForm();">
                            <div class="form-group">
                                <label for="txtFname" class="col-sm-2 control-label">Full Name</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtFname" id="txtFname" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtemail" class="col-sm-2 control-label">Email Address</label>
                                <div class="col-sm-8">
                                    <input type="email" class="form-control1" name="txtemail" id="txtemail" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtcontactno" class="col-sm-2 control-label">Contact Number</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtcontactno" id="txtcontactno" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtUname" class="col-sm-2 control-label">Username</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control1" name="txtUname" id="txtUname" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtpswd" class="col-sm-2 control-label">Password</label>
                                <div class="col-sm-8">
                                    <input type="password" class="form-control" name="txtpswd" id="txtpswd" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="txtpswd2" class="col-sm-2 control-label">Confirm Password</label>
                                <div class="col-sm-8">
                                    <input type="password" class="form-control" name="txtpswd2" id="txtpswd2" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-8 col-sm-offset-2">
                                    <button type="submit" name="submit" class="btn-primary btn">Create</button>
                                </div>
                            </div>
                        </form>
                        <?php if ($msg): ?>
                            <script>
                                showMessage("<?php echo $msg; ?>");
                            </script>
                        <?php endif; ?>
                        <?php if ($error): ?>
                            <script>
                                showError("<?php echo $error; ?>");
                            </script>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-sm-8 col-sm-offset-2">
                                <a href="admin_dashboard.html" class="btn btn-primary">Back to Dashboard</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="inner-block"></div>
            </div>
        </div>
    </div>
</body>
</html>
