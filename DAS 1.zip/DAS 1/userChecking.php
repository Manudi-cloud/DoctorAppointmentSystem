<?php
session_start();
include("DBConnection.php");

if (!isset($_SESSION['error'])) {
    $_SESSION['error'] = "";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['txtusername']);
    $pswd = trim($_POST['txtpswd']);

    if (empty($user) || empty($pswd)) {
        $_SESSION['error'] = "Please enter both username and password.";
        header('Location: login.php');
        exit;
    }

    // 1. Admin login
    $stmt = $con->prepare("SELECT password FROM admin_details WHERE username = ?");
    if ($stmt) {
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($storedPassword);
            $stmt->fetch();

            if ($pswd == $storedPassword) {
                $_SESSION['login'] = $user;
                $_SESSION['success'] = "Admin login successful!";
                setcookie("log", "admin", time() + 600);
                
                echo "<script>alert('Admin login successful!');window.location.href='admin_dashboard.html';</script>";
                exit;
            }
        }
        $stmt->close();
    }

    // 2. Patient login
    
    $stmt = $con->prepare("SELECT patient_Id, password FROM patient_details WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
      $stmt->bind_result($patient_id, $storedPassword);
      $stmt->fetch();

    if ($pswd === $storedPassword) { // plain text check
        $_SESSION['patient_id'] = $patient_id;   // ✅ Store ID in session
        $_SESSION['login'] = $user;
        $_SESSION['success'] = "Patient login successful!";
        setcookie("log", "patient", time() + 600);

        echo "<script>alert('Patient login successful!');window.location.href='patient_dashboard.html';</script>";
        exit;
      }
    }


    // 3. Doctor login
    $stmt = $con->prepare("SELECT doctor_Id, doc_name, dpassword FROM doctor_details WHERE doc_email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($doctorId, $doctorName, $storedPassword);
            $stmt->fetch();

            if ($pswd === $storedPassword) { // plain text
                $_SESSION['doctor_id']   = $doctorId;
                $_SESSION['doctor_name'] = $doctorName;
                $_SESSION['doctor_email'] = $user;
                $_SESSION['login']       = $user;
                $_SESSION['success']     = "Doctor login successful!";
                setcookie("log", "doctor", time() + 600);

                echo "<script>alert('Doctor login successful!');window.location.href='doctor_dashboard.php';</script>";
                exit;
            } else {
                $_SESSION['error'] = "Invalid password!";
                header('Location: login.php');
                exit;
            }
        } else {
            $_SESSION['error'] = "User not found!";
            header('Location: login.php');
            exit;
        }
        $stmt->close();
    }

    // Nothing matched
    $_SESSION['error'] = "Incorrect username/email or password. Please try again.";
    header('Location: login.php');
    exit;
}

$con->close();
?>
