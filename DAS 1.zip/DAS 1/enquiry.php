<?php
session_start();
include('DBConnection.php');

// Initialize variables for error and success messages
$error = "";
$success = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Validate the inputs
    if (empty($name) || empty($email) || empty($message)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Prepare and bind the insert statement
        $stmt = $con->prepare("INSERT INTO tblenquiries (name, email, message) VALUES (?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . htmlspecialchars($con->error));
        }
        
        $stmt->bind_param("sss", $name, $email, $message);

        // Execute the statement
        if ($stmt->execute()) {
            $success = "Enquiry sent successfully!";
        } else {
            $error = "Failed to send enquiry: " . htmlspecialchars($stmt->error);
        }

        $stmt->close();
    }
}

// Close the database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Enquiry</title>
    <link rel="icon" type="image/x-icon" href="../Pages/images/logo new.ico">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->

    <style>
body {
    font-family: 'Roboto', sans-serif;
    background: linear-gradient(135deg, #ffffff, #f0f0f0);
    margin: 0;
    padding: 0;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container-e {
    width: 400px;
    padding: 30px;
    background: #ffffff;
    border-radius: 15px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease-in-out;
    text-align: center;
    margin-left: 35%;
    margin-top: 20px;
}

.container-e:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
}

h1 {
    font-size: 30px;
    color: #333;
    margin-bottom: 20px;
    border-bottom: 2px solid #f1f1f1;
    padding-bottom: 10px;
}

label {
    font-size: 20px;
    color: #666;
    display: block;
    margin: 10px 0 5px;
    text-align: left;
}

input, textarea {
    width: 100%;
    padding: 12px 15px;
    margin: 5px 0 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-sizing: border-box;
    transition: border-color 0.3s;
    outline: none;
}

input:focus, textarea:focus {
    border-color: #3498db;
    box-shadow: 0 0 8px rgba(52, 152, 219, 0.2);
}

textarea {
    height: 100px;
    resize: none;
}

button {
    width: 100%;
    padding: 12px 15px;
    background: #3498db;
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s, transform 0.2s;
}

button:hover {
    background: #2980b9;
    transform: translateY(-3px);
}

/* SweetAlert custom styles */
.swal2-popup {
    font-family: 'Roboto', sans-serif;
    border-radius: 15px !important;
}

.swal2-title {
    font-size: 20px !important;
    color: #333 !important;
}

.swal2-content {
    font-size: 16px !important;
}

@media screen and (max-width: 600px) {
    .container-e {
        width: 90%;
    }

    h1 {
        font-size: 20px;
    }

    button {
        font-size: 14px;
    }
}

        </style>

   
</head>
<body>

   
<div class="container-e">
    <h1>Send Enquiry</h1>
    
    <form method="post" action="enquiry.php" onsubmit="return validateForm();">
        <label for="name">Full Name:</label>
        <input type="text" name="name" id="name" required>
        
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        
        <label for="message">Message:</label>
        <textarea name="message" id="message" required></textarea>
        
        <button type="submit">Send Enquiry</button>

    </form>

    </div>
        <a href="user_dashboard.php">Back to Dashboard</a>
    </div>
</div>

<script>
    // Function to display SweetAlert for success and error messages
    function showAlert(title, text, icon) {
        Swal.fire({
            title: title,
            text: text,
            icon: icon,
            confirmButtonText: 'OK'
        });
    }

    // Check if there are error or success messages to show
    <?php if ($error): ?>
        showAlert('Error', '<?php echo addslashes($error); ?>', 'error');
    <?php endif; ?>
    
    <?php if ($success): ?>
        showAlert('Success', '<?php echo addslashes($success); ?>', 'success');
    <?php endif; ?>
</script>




</body>
</html>
