<?php
include("DBConnection.php");

if(!isset($_GET['id'])) {
    die("Patient ID missing!");
}
$id = intval($_GET['id']);

// Fetch patient details
$sql = "SELECT * FROM patient_details WHERE patient_Id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows === 0) {
    die("Patient not found!");
}

$patient = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Patient</title>
</head>
<body>
    <h2>Edit Patient Details</h2>
    <form action="updatePatient.php" method="post">
        <input type="hidden" name="patient_Id" value="<?= $patient['patient_Id']; ?>">

        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($patient['name']); ?>" required><br>

        <label>Gender:</label>
        <input type="text" name="gender" value="<?= htmlspecialchars($patient['gender']); ?>" required><br>

        <label>Address:</label>
        <input type="text" name="address" value="<?= htmlspecialchars($patient['address']); ?>"><br>

        <label>Contact Number:</label>
        <input type="text" name="contactnumber" value="<?= htmlspecialchars($patient['contactnumber']); ?>"><br>

        <label>Date of Birth:</label>
        <input type="date" name="dob" value="<?= $patient['dob']; ?>"><br>

        <label>Email Address:</label>
        <input type="text" name="email_address" value="<?= htmlspecialchars($patient['email_address']); ?>"><br>

        <button type="submit" name="update">Update Patient</button>
    </form>
</body>
</html>
