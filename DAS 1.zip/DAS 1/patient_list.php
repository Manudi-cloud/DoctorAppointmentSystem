<?php
include("DBConnection.php");

$sql = "SELECT patient_Id, name, gender, address, contactnumber, dob, email_address FROM patient_details";
$result = mysqli_query($con, $sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Patient</title>
    <link rel="stylesheet" href=".css">
</head>
<body>
    <h2>Patient Management</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Contact number</th>
                <th>Date of Birth</th>
                <th>Email Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $row['patient_Id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['gender']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td><?php echo htmlspecialchars($row['contactnumber']); ?></td>
                <td><?php echo htmlspecialchars($row['dob']); ?></td>
                <td><?php echo htmlspecialchars($row['email_address']); ?></td>
                <td>
                    <!-- update patient -->
                    <a href="editPatient.php?id=<?= $row['patient_Id']; ?>" class="btn-edit">Update</a>

                    <!-- Delete patient -->
                    <a href="deletePatient.php?id=<?= $row['patient_Id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this patient?');" 
                       class="btn-delete">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <a href="admin_dashboard.html">Back to Dashboard</a>
</body>
</html>
<?php mysqli_close($con); ?>

   