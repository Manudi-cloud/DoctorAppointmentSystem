<?php
session_start();
include('DBConnection.php');

// Initialize variables for error and success messages
$error = "";
$success = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientName = trim($_POST['patient_Name']);
    $reviewBrief = trim($_POST['review_brief']);
    $reviewDetail = trim($_POST['review_detail']);

    // Validate the inputs
    if (empty($patientName) || empty($reviewBrief) || empty($reviewDetail)) {
        $error = "All fields are required.";
    } else {
        // Prepare and bind the insert statement
        $stmt = $con->prepare("INSERT INTO tblreview (patient_Name, review_brief, review_detail) VALUES (?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . htmlspecialchars($con->error));
        }
        
        $stmt->bind_param("sss", $patientName, $reviewBrief, $reviewDetail);

        // Execute the statement
        if ($stmt->execute()) {
            $success = "Review submitted successfully!";
        } else {
            $error = "Failed to submit review: " . htmlspecialchars($stmt->error);
        }

        $stmt->close();
    }
}

// Fetch reviews for display
$reviews = [];
$sql = "SELECT patient_Name, review_brief, review_detail FROM tblreview";
$result = mysqli_query($con, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $reviews[] = $row;
    }
}

// Close the database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Review</title>
    <link rel="icon" type="image/x-icon" href="../Pages/images/logo new.ico">
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], textarea {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .section_container {
            margin-top: 30px;
        }
        .section_grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        .review_card {
            background: #f1f1f1;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .review_card h3 {
            margin-top: 0;
            color: #333;
        }
        .review_card p {
            margin: 5px 0;
        }
        .message {
            text-align: center;
            margin-bottom: 20px;
        }
        .message.error {
            color: red;
        }
        .message.success {
            color: green;
        }
    </style>
</head>
<body>

  <!--include header -->
  <?php include('header.php');?> 

<div class="container">
    <h1>Submit Your Review</h1>
    
    <form method="post" action="">
        <label for="traveler_name">Name:</label>
        <input type="text" name="patient_Name" id="patient_Name" required>
        
        <label for="review_brief">Review Brief:</label>
        <input type="text" name="review_brief" id="review_brief" required>
        
        <label for="review_detail">Review Details:</label>
        <textarea name="review_detail" id="review_detail" required></textarea>
        
        <button type="submit">Submit Review</button>
    </form>

    <!-- Display success or error messages -->
    <script>
        function showAlert(title, text, icon) {
            Swal.fire({
                title: title,
                text: text,
                icon: icon,
                confirmButtonText: 'OK'
            });
        }

        <?php if ($error): ?>
            showAlert('Error', '<?php echo addslashes($error); ?>', 'error');
        <?php endif; ?>
        
        <?php if ($success): ?>
            showAlert('Success', '<?php echo addslashes($success); ?>', 'success');
        <?php endif; ?>
    </script>

    <section class="section_container">
        <h1>What Our Patients Say</h1>
        <div class="section_grid">
            <?php if (!empty($reviews)): ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review_card">
                        <h3><?php echo htmlspecialchars($review['patient_Name']); ?></h3>
                        <p><strong><?php echo htmlspecialchars($review['review_brief']); ?></strong></p>
                        <p><?php echo nl2br(htmlspecialchars($review['review_detail'])); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No reviews available at the moment.</p>
            <?php endif; ?>
        </div>
    </section>

    <div class="message">
        <a href="patient_dashboard.html" class="btn btn-primary">Back to Dashboard</a>
    </div>
</div>

 <!--include footer -->
 <?php include('footer.php');?>  

</body>
</html>
